# PragyaBodha

Financial Wisdom Platform

## Structure
- `frontend/` - Web application
- `backend/` - Firebase configuration

## Deploy
Push to GitHub and import to Vercel. Vercel serves `frontend/` automatically.
