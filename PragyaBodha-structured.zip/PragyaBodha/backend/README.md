# Backend

Firebase backend configuration

## Services
- Firebase Authentication (Email/Password, Google)
- Cloud Firestore Database

## Setup
1. Enable Authentication providers in Firebase Console
2. Deploy Firestore rules: `firebase deploy --only firestore:rules`
